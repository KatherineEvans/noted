<template>
    <div class="flex items-center gap-x-6 bg-green-950 px-6 py-2.5 sm:px-3.5 sm:before:flex-1">
        <p class="text-sm leading-6 text-white max-w-full md:max-w-4xl">
            <div>
                <strong class="font-semibold">Welcome to Noted,</strong>
                an app designed to help you keep track of the application and interview process.
            </div>
            <div>Build as Laravel/Vue monolith using Inertia.js, the app features a dockerized backend (Laravel Sail), MySQL database, Redis, and Horizon queue management</div>
        </p>
        <div class="flex flex-1 justify-end"></div>
    </div>
</template>

<script setup></script>
