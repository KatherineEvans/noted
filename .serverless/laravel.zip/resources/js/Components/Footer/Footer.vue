<template>
    <footer class="bg-white text-center" aria-labelledby="footer-heading">
        <h2 id="footer-heading" class="sr-only">Footer</h2>
        <div class="mx-auto max-w-7xl px-6 pb-8 pt-4 sm:pt-8 lg:px-8 lg:pt-8">
            <div class="mt-4 border-t border-gray-900/10 pt-8">
                <p class="text-xs leading-5 text-gray-500">&copy; 2023 You Should Hire Me!</p>
            </div>
        </div>
    </footer>
</template>
<script></script>
